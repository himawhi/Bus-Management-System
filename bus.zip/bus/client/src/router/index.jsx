import React from "react";
import { BrowserRouter } from "react-router-dom";

import AdminRoutes from "./AdminRoutes";

const Router = () => {
    return (
        <BrowserRouter>
            <AdminRoutes />
        </BrowserRouter>
    );
};

export default Router;
