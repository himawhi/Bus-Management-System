import React, { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { Navigate } from "react-router-dom";
import { toast } from "react-toastify";
import { ToastContainer } from "react-toastify";

import NavBar from "../../components/admin/NavBar";
import { Input, Button } from "../../components/ui";
import { userLoggedIn } from "../../redux/actions/userActions";

const Loginform = () => {
    const user = useSelector((state) => state.user);
    const dispatch = useDispatch();

    const inputDataStructure = {
        driverID: {
            key: "driverID",
            label: "Driver ID",
            data: "",
            type: "text",
            isValid: true,
            error: "",
        },
        password: {
            key: "password",
            label: "Password",
            data: "",
            type: "password",
            isValid: true,
            error: "",
        },
    };

    const [inputs, setInputs] = useState(inputDataStructure);

    const handleChange = (data, input) => {
        input.data = data;

        let input_list = { ...inputs };
        input_list[input.key] = input;
        setInputs(input_list);
    };

    const handleSubmit = async () => {
        const event = window.event;
        event.preventDefault();

        // let data = {
        //     email: inputs.email.data,
        //     password: inputs.password.data,
        // };

        try {
            //const result = await login(data);

            toast.success("Logged in successfully!");

            const userData = {
                //token: result.token,
                name: "Janith perera",
                email: "janithperera20@gmail.com",
                avatar: "",
            };

            setTimeout(() => {
                dispatch(userLoggedIn(userData));
            }, 1000);
        } catch (e) {
            toast.error(e);
        }
    };

    if (user.authenticated) {
        return <Navigate to="/" />;
    }

    return (
        <div className="bg-img h-screen w-full flex justify-center items-center">
            <NavBar />
            <ToastContainer />
            <form className="drop-blur-lg bg-white dark:bg-black dark:bg-opacity-30 bg-opacity-80  w-[80vw] lg:w-[40vw] pb-20 mx-auto mt-[20%] lg:mt-[5%]  shadow-lg rounded-xl  bg-clip-padding  flex flex-col items-center">
                <h2 className="w-full  text-center bg-[#55efc4] text-white font-bold text-2xl md:text-2xl  mb-2 rounded-t-lg py-1">
                    login
                </h2>
                <img
                    src={require("../../assets/img/logo.jpeg")}
                    className="w-48"
                />

                <div className="w-4/5">
                    <Input
                        input={inputs.driverID}
                        handleChange={handleChange}
                    />
                    <Input
                        input={inputs.password}
                        handleChange={handleChange}
                    />
                </div>

                <div className="w-4/5">
                    <Button text="Login" handleClick={handleSubmit} />
                </div>
            </form>
        </div>
    );
};

export default Loginform;
