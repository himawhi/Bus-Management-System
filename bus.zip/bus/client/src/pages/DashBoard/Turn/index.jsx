import React, { useEffect, useState } from "react";
import { Table } from "antd";
import { Navigate } from "react-router-dom";

import { Button } from "../../../components/ui";
import { getTurns } from "../../../http/turn";

const TurnSection = () => {
    const [turns, setTurns] = useState([]);

    const refreshUsers = async () => {
        try {
            const turns = await getTurns();
            setTurns(turns);
        } catch (e) {
            console.log(e);
        }
    };

    useEffect(() => {
        refreshUsers();
        const intervalId = setInterval(refreshUsers, 10000);

        return () => clearInterval(intervalId);
    }, []);

    const actionBtns = () => {
        return (
            <div className="flex">
                <a href="/map">
                    <Button
                        text="View"
                        className={
                            "ml-3 hover:bg-primary hover:text-white px-[14px]"
                        }
                    />
                </a>
            </div>
        );
    };

    const columns = [
        {
            title: "Name",
            align: "center",
            width: "40%",
            render: (arg) => {
                return "Turn - " + arg.turnNo;
            },
        },
        {
            title: "Turn time",
            dataIndex: "turnTime",
            key: "turnTime",
            align: "center",
            width: "10%",
        },
        {
            title: "Route name",
            dataIndex: "routeName",
            key: "routeName",
            align: "center",
            width: "40%",
            sorter: (a, b) => a.name.localeCompare(b.name),
        },

        {
            title: "Turn Operations",
            dataIndex: "",
            key: "operations",
            align: "center",
            width: "20%",
            render: (arg) => actionBtns(arg),
        },
    ];

    return (
        <section className="w-full">
            <div className="mx-auto w-[95%]">
                <Table columns={columns} dataSource={turns} />
            </div>
        </section>
    );
};

export default TurnSection;
