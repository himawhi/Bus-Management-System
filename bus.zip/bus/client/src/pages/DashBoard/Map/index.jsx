import React from "react";
import { GoogleMap, LoadScript } from "@react-google-maps/api";

const containerStyle = {
    width: "100%",
    height: "400px",
};

const center = {
    lat: 37.7749, // Set your desired latitude
    lng: -122.4194, // Set your desired longitude
};

const MapSection = () => {
    return (
        <section className="w-full">
            <div className="mx-auto w-[95%]">
                <LoadScript googleMapsApiKey="YOUR_API_KEY">
                    {" "}
                    {/* Replace YOUR_API_KEY with your actual Google Maps API key */}
                    <GoogleMap
                        mapContainerStyle={containerStyle}
                        center={center}
                        zoom={10}
                    />
                </LoadScript>
            </div>
        </section>
    );
};

export default MapSection;
