import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";

import { Button, Input, Select } from "../../../components/ui";
import { Navigate } from "react-router-dom";
import { sendAttendence } from "../../../http/attendence";

const AttendenceSection = () => {
    const inputDataStructure = {
        driverId: {
            key: "driverId",
            label: "Driver ID",
            placeholder: "Enter your driver ID",
            data: "",
            type: "text",
            error: null,
        },
        status: {
            key: "status",
            label: "Select your status",
            data: "",
            optList: [
                { id: "present", title: "Present" },
                { id: "absent", title: "Absent" },
            ],
            error: null,
        },
    };

    const [inputs, setInputs] = useState(inputDataStructure);
    const [redirect, setRedirection] = useState(false);

    const handleChange = (data, input) => {
        input.data = data;

        let input_list = { ...inputs };
        input_list[input.key] = input;
        setInputs(input_list);
    };

    const handleSubmit = async () => {
        const e = window.event;
        e.preventDefault();

        const data = {
            driverID: inputs.driverId.data,
            status: inputs.status.data,
        };

        try {
            const result = sendAttendence(data);

            toast.success("Submitted successfully!");

            setTimeout(() => {
                setRedirection(true);
            }, 2000);
        } catch (e) {
            toast.error(e);
        }
    };

    if (redirect) {
        return <Navigate to={"/turns"} />;
    }

    return (
        <section className="w-full">
            <div className="container w-[90%] mx-auto bg-gray-100 rounded-lg shadow-md p-4 mb-4">
                <div className="grid grid-cols-2 gap-3">
                    <Input
                        input={inputs.driverId}
                        handleChange={handleChange}
                    />
                    <Select input={inputs.status} handleChange={handleChange} />
                </div>
                <Button text="Submit" handleClick={handleSubmit} />
            </div>
        </section>
    );
};

export default AttendenceSection;
