import React from "react";
import NavBar from "../../components/admin/NavBar";
import SideBar from "../../components/admin/SideBar";

import HomeSection from "./Home";
import TurnSection from "./Turn";
import MapSection from "./Map";
import BreakdownSection from "./Breakdown";
import AttendenceSection from "./Attendence";
import SettingSection from "./Settings";

const Dashboard = ({ section }) => {
    return (
        <div>
            <NavBar />
            <div className="flex mt-[85px] gap-6">
                <div className="w-[220px] p-10 bg-primary fixed h-screen -mt-12">
                    <SideBar section={section} />
                </div>
                <div className="w-full ml-[220px] ">
                    {section == "home" && <HomeSection />}
                    {section == "attendence" && <AttendenceSection />}
                    {section == "turns" && <TurnSection />}
                    {section == "map" && <MapSection />}
                    {section == "breakdown" && <BreakdownSection />}
                    {section == "settings" && <SettingSection />}
                </div>
            </div>
        </div>
    );
};

export default Dashboard;
