import React, { useState } from "react";
import { useSelector } from "react-redux";

const Settings = () => {
    const user = useSelector((state) => state.user.data);

    return (
        <section className="w-full">
            <div className="p-16">
                <div className="p-8 bg-white shadow">
                    <div>
                        <div className="relative">
                            <div className="w-48 h-48 bg-indigo-100 mx-auto rounded-full shadow-2xl   flex items-center justify-center text-indigo-500">
                                <img
                                    className="rounded-full h-44 w-44"
                                    src={require("../../../assets/img/profile.png")}
                                />
                            </div>
                        </div>
                    </div>
                    <div className="mt-20 text-center border-b pb-12">
                        <h1 className="text-4xl font-medium text-gray-700">
                            {user.name}
                        </h1>
                        <p className="font-light text-gray-600 mt-3">
                            {user.phoneNumber}
                        </p>
                        <p className="mt-2 text-gray-500">
                            Email:janithperera20@gmail.com
                        </p>
                        <p className="mt-2 text-gray-500">
                            Phone:+94 765340192
                        </p>
                        <p className="mt-2 text-gray-500">
                            Address:No 329/A,Kanuwana,Jaela. Job Role:Driver
                        </p>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Settings;
