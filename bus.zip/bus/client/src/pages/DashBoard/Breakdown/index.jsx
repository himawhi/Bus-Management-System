import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";

import { Button, Input, Select } from "../../../components/ui";
import { Navigate } from "react-router-dom";

const BreakdownSection = () => {
    const inputDataStructure = {
        lateDuration: {
            key: "lateDuration",
            label: "",
            data: "",
            optList: [
                { id: "5", title: "5 minutes" },
                { id: "10", title: "10 minutes" },
                { id: "15", title: "15 minutes" },
                { id: "20", title: "20 minutes" },
                { id: "25", title: "25 minutes" },
            ],
            error: null,
        },
    };

    const [inputs, setInputs] = useState(inputDataStructure);
    const [redirect, setRedirection] = useState(false);

    const handleChange = (data, input) => {
        input.data = data;

        let input_list = { ...inputs };
        input_list[input.key] = input;
        setInputs(input_list);
    };

    const handleSendNotification = async () => {
        const e = window.event;
        e.preventDefault();

        try {
            toast.success("Notification was sent successfully!");

            setTimeout(() => {
                setRedirection(true);
            }, 2000);
        } catch (e) {
            toast.error(e);
        }
    };
    const handleReportToAdmin = async () => {
        const e = window.event;
        e.preventDefault();

        try {
            toast.success("Reported to the depot admin successfully!");

            setTimeout(() => {
                setRedirection(true);
            }, 2000);
        } catch (e) {
            toast.error(e);
        }
    };
    const handleReportToPassengers = async () => {
        const e = window.event;
        e.preventDefault();

        try {
            toast.success("Reported to the passengers successfully!");

            setTimeout(() => {
                setRedirection(true);
            }, 2000);
        } catch (e) {
            toast.error(e);
        }
    };
    const handleEndRoute = async () => {
        const e = window.event;
        e.preventDefault();

        try {
            toast.success("The route ended successfully!");

            setTimeout(() => {
                setRedirection(true);
            }, 2000);
        } catch (e) {
            toast.error(e);
        }
    };

    return (
        <section className="w-full">
            <div className="container w-[90%] mx-auto">
                <div className="bg-gray-100 rounded-lg shadow-md p-4 mb-4">
                    <h2 className="text-lg font-bold mb-2">
                        Send late notification
                    </h2>
                    <div className="grid grid-cols-2 gap-3">
                        <Select
                            input={inputs.lateDuration}
                            handleChange={handleChange}
                        />
                        <Button
                            text="Send Notification"
                            handleClick={handleSendNotification}
                        />
                    </div>
                </div>

                <div className="bg-gray-100 rounded-lg shadow-md p-4 mb-4">
                    <h2 className="text-lg font-bold mb-2">
                        Unrecoverble breakdown?
                    </h2>
                    <div className="grid grid-cols-2 gap-3">
                        <Button
                            text="Report to depot admin"
                            handleClick={handleReportToAdmin}
                        />
                        <Button
                            text="Report to passengers"
                            handleClick={handleReportToPassengers}
                        />
                        <Button text="End Route" handleClick={handleEndRoute} />
                    </div>
                </div>
            </div>
        </section>
    );
};

export default BreakdownSection;
