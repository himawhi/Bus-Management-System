import React from "react";
import { FaUsers, FaUser, FaCheckDouble } from "react-icons/fa";

import SingleCounter from "./SingleCounter";

const CounterSection = ({ countData }) => {
    const counts = [
        { title: "Total turns", count: 12, icon: <FaUsers /> },
        {
            title: "Completed turns",
            count: 4,
            icon: <FaUser />,
        },
        {
            title: "Pending turns",
            count: 8,
            icon: <FaCheckDouble />,
        },
    ];

    return (
        <div className="flex flex-wrap">
            {counts.map((item) => {
                return <SingleCounter item={item} />;
            })}
        </div>
    );
};

export default CounterSection;
