import Axios from "axios";

export const sendAttendence = (data) => {
    return new Promise((resolve, reject) => {
        Axios.post("http://localhost:8080/api/attendance", data)
            .then((response) => {
                if (response.status == 200) {
                    return resolve(response.data);
                }
            })
            .catch((e) => {
                return reject(e.response.data.message);
            });
    });
};
