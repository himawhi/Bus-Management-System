import Axios from "axios";

export const getTurns = () => {
    return new Promise((resolve, reject) => {
        Axios.get("http://localhost:8080/api/view")
            .then((response) => {
                if (response.status == 200) {
                    return resolve(response.data);
                }
            })
            .catch((e) => {
                return reject(e.response.data.message);
            });
    });
};
