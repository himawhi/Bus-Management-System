import React from "react";
import "react-toastify/dist/ReactToastify.css";
import { ToastContainer } from "react-toastify";

const NavBar = () => {
    return (
        <div>
            <ToastContainer />

            <nav className="header-nav z-30 fixed top-0 left-0 w-full h-16 bg-white shadow-lg">
                <div className="container m-auto flex justify-between items-center text-gray-700">
                    <a href="/">
                        <img
                            className="h-[60px] bg-white pb-1 pt-1"
                            src={require("../../../assets/img/logo.jpeg")}
                            alt="Logo"
                        ></img>
                    </a>
                    <div className="flex items-center">
                        <img
                            className="h-8 w-8 rounded-full mr-2"
                            src={require("../../../assets/img/profile.png")}
                            alt="Profile"
                        />
                        <span className="text-gray-700 font-medium">
                            Janith Perera
                        </span>
                    </div>
                </div>
            </nav>
        </div>
    );
};

export default NavBar;
