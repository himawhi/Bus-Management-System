import React from "react";

import ListItem from "./listItem";

import {
    FaUser,
    FaUsers,
    FaHome,
    FaMoneyCheck,
    FaWhmcs,
    FaPowerOff,
} from "react-icons/fa";

const SideBar = ({ section }) => {
    const navList = [
        {
            id: 1,
            title: "Home",
            url: "/",
            icon: <FaHome />,
            selected: section == "home",
        },
        {
            id: 5,
            title: "Attendance",
            url: "/attendence",
            icon: <FaMoneyCheck />,
            selected: section == "attendence",
        },

        {
            id: 4,
            title: "Turns",
            url: "/turns",
            icon: <FaUsers />,
            selected: section == "turns",
        },
        {
            id: 5,
            title: "Breakdown",
            url: "/breakdown",
            icon: <FaUsers />,
            selected: section == "breakdown",
        },

        {
            id: 7,
            title: "Settings",
            url: "/settings",
            icon: <FaPowerOff />,
            selected: section == "settings",
        },
        {
            id: 7,
            title: "Logout",
            url: "/logout",
            icon: <FaPowerOff />,
        },
    ];

    return (
        <ul className="space-y-4 mb-12 mt-8 w-full">
            {navList.map((item) => (
                <ListItem key={item.id} item={item} />
            ))}
        </ul>
    );
};
export default SideBar;
